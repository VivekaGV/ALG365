package OOPs;

public class Employee {
    private String name ;
    private String role ;
    private String id ;
    
    public Employee(String employeename,String employeerole,String employeeid){
      this.name = employeename;
      this.role = employeerole;
      this.id = employeeid;
    }
    
}
