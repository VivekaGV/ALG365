package Interfaceoops;

public class AITlibmanagement implements LibManagement{
     public void checkout(){
        System.out.println("Check out in AIT ");
    }

    
}

   