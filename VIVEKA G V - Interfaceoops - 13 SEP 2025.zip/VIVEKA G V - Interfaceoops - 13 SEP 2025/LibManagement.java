package Interfaceoops;
interface LibManagement {

    public int bookcount;
    public void init();
    public void checkout();
    public void checkin();
    public void dissplaystatus();

    
}
