package Interfaceoops;

public class SIETLibManagement implements LibManagement {
     public void checkout(){
        System.out.println("Check out in SIET ");
    }

    
}

   